#!/bin/bash
git pull https://aaronainzon17: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@github.com/aaronainzon17/robotics